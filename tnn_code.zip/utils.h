#ifndef EXP_CODE_TDT_MODEL_H_
#define EXP_CODE_TDT_MODEL_H_

#include <fstream>
#include <set>
#include <map>
#include <string>
#include <utility>
#include <vector>
#include <deque>
#include <climits>

#include "file_io.h"
#include "header.h"
#include "obj2str.h"

using namespace std;
namespace utils {
    struct {
        std::string cmd;
        std::string inputgraph;
        std::string baseFolder;
        double stop_p;

        int vorder_strategy;
        int h2h_reduce_strategy = 0;
    } params;

    struct undirected_tt_attr {
        std::vector<std::pair<int, int>> ott, itt;
    };

    void write(FILE *ofile, const utils::undirected_tt_attr &v) {
        write(ofile, v.itt);
        write(ofile, v.ott);
    }

    void read(FILE *ifile, utils::undirected_tt_attr &v) {
        read(ifile, v.itt);
        read(ifile, v.ott);
    }

    struct edge_timetable {
        edge_timetable() = default;
        explicit edge_timetable(int dst) : dst(dst), timeTable(){};
        explicit edge_timetable(int dst, const std::vector<std::pair<int, int>> &tt) : dst(dst), timeTable(tt){};
        int dst;                                    //destination
        std::vector<std::pair<int, int>> timeTable; //timetable, assume timetable is sorted.
    };

    struct tn_vertex {
        std::vector<edge_timetable> onb, inb;
    };

    struct graph_transportation {
        std::vector<tn_vertex> vertices;
    };


    graph_transportation loading_graph_bin(const std::string &path);

    struct algs {

        static void pruning_tt_inplace(std::vector<pair<int, int>> &tt) {
            //sort, I with smaller I.first comes first, if .first is equal, larger I.second comes first then.
            sort(tt.begin(), tt.end(), [](pair<int, int> a, pair<int, int> b) {
                if (a.first != b.first) return a.first < b.first;
                return a.second > b.second;
            });
            vector<bool> removed(tt.size(), false);
            int smallest_second_on_right = tt.back().second;
            for (int i = tt.size() - 2; i >= 0; --i) {
                if (tt[i].second >= smallest_second_on_right) {
                    removed[i] = true;
                } else {
                    smallest_second_on_right = tt[i].second;
                }
            }
            int p = 0;
            for (int i = 0; i < tt.size(); ++i) {
                if (!removed[i]) { tt[p++] = tt[i]; }
            }
            tt.resize(p);
        }

        template<class C1, class C2>
        static vector<pair<int, int>> join_tt(const C1 &A, const C2 &B) {
            vector<pair<int, int>> result;
            if (A.empty() || B.empty()) return result;
            int iA = 0, iB = 0;
            while (true) {
                while (iB < B.size() && A[iA].second > B[iB].first) {//non-feasible loop
                    iB++;
                }
                if (iB == B.size()) { break; }
                int fA = -1;
                while (iA < A.size() && A[iA].second <= B[iB].first) {//feasible loop
                    fA = iA;
                    iA++;
                }
                result.emplace_back(A[fA].first, B[iB].second);

                if (iA == A.size()) { break; }
            }

            return result;
        }

        template<class C1, class C2>
        static bool combine_tt_inplace(C1 &A, const C2 &B) {
            bool updated = false;
            C1 result;
            int iA = 0, iB = 0;
            while (iA < A.size() && iB < B.size()) {
                if (A[iA].first < B[iB].first) {
                    if (A[iA].second < B[iB].second) {
                        result.push_back(A[iA]);
                    }
                    iA++;
                } else if (A[iA].first == B[iB].first) {
                    if (A[iA].second <= B[iB].second) {
                        result.push_back(A[iA]);
                    } else {// 2.3
                        updated = true;
                        result.push_back(B[iB]);
                    }
                    iA++, iB++;
                } else { 
                    if (A[iA].second > B[iB].second) {
                        updated = true;
                        result.push_back(B[iB]);
                    }
                    iB++;
                }
            }
            while (iA < A.size()) { result.push_back(A[iA++]); }
            while (iB < B.size()) {
                updated = true;
                result.push_back(B[iB++]);
            }
            swap(A, result);
            return updated;
        }

        template<class C1, class C2>
        static vector<pair<int, vector<pair<int, int>>>> join_tt_knn_vec(const C1 &tt, const C2 &knn, const int poi, const int k_max) {
            vector<pair<int, vector<pair<int, int>>>> new_knn;
            if (tt.empty()) return new_knn;

            int i_tt = 0, i_knn = 0;
            if (!knn.empty()) {
                while (true) {
                    while (i_knn < knn.size() && knn[i_knn].first < tt[i_tt].second) {
                        i_knn++;
                    }
                    if (i_knn == knn.size()) break;

                    auto knn_tmp = knn[i_knn].second;   
                    if (poi > -1) { // if it is a poi                     
                        if (knn_tmp.size() >= k_max && knn_tmp[k_max-1].second <= tt[i_tt].second) {
                            new_knn.emplace_back(tt[i_tt].first, knn_tmp);
                            i_tt++;
                            continue;
                        }
                        int pos;                                            
                        for (pos = 0; pos < knn_tmp.size(); pos++) {
                            if (knn_tmp[pos].second >= tt[i_tt].second) break;
                        }
                        knn_tmp.emplace(knn_tmp.begin()+pos, make_pair(poi, tt[i_tt].second)); 
                    }

                    if (knn_tmp.size() > k_max) knn_tmp.resize(k_max);
                    
                    // Jump tt to next avaliable one
                    if (poi > -1) {
                        new_knn.emplace_back(tt[i_tt].first, knn_tmp);
                        i_tt++;
                    } else {
                        while (tt[i_tt].second <= knn[i_knn].first && i_tt < tt.size()) {
                            i_tt++;
                        }
                        
                        new_knn.emplace_back(tt[i_tt-1].first, knn_tmp);
                        if (i_tt == tt.size()) break;
                    }
                    
                    if (i_tt == tt.size()) break;                   
                }
            }

            if (poi > -1) {
                while (i_tt < tt.size()) {   // if w is a poi, add new latest poi_knn_lists
                        vector<pair<int, int>> new_knn_td;
                        new_knn_td.emplace_back(poi, tt[i_tt].second);
                        new_knn.emplace_back(tt[i_tt].first, new_knn_td);
                        i_tt++;
                }
            }
            return new_knn;
        }

        // OP
        template<class C1, class C2, class C3>
        static vector<pair<int, vector<pair<int, int>>>> join_tt_knn_vec(const C1 &tt, const C2 &knn, const int poi, const C3 &opening_hour, const int k_max) {
            if (opening_hour.size() == 0) // either 24h openning or not a poi
                return join_tt_knn_vec(tt, knn, poi, k_max);
            
            vector<pair<int, vector<pair<int, int>>>> new_knn;
            if (tt.empty()) return new_knn;

            int i_tt = 0, i_knn = 0;
            if (!knn.empty()) {
                while (true) {
                    if (i_tt == tt.size()) break;
                    while (i_knn < knn.size() && knn[i_knn].first < tt[i_tt].second) {
                        i_knn++;
                    }
                    if (i_knn == knn.size()) break;

                    auto knn_tmp = knn[i_knn].second;   
                    if (poi > -1) { // if it is a poi
                        auto poi_open_time = get_opening_arrival_time(tt[i_tt].second, opening_hour);          
                        if ((knn_tmp.size() >= k_max && knn_tmp[k_max-1].second <= poi_open_time) || poi_open_time == INT32_MAX) {
                            new_knn.emplace_back(tt[i_tt].first, knn_tmp);
                            i_tt++;
                            continue;
                        }
                        int pos;                                            
                        for (pos = 0; pos < knn_tmp.size(); pos++) {
                            if (knn_tmp[pos].second >= poi_open_time) break;
                        }
                        knn_tmp.emplace(knn_tmp.begin()+pos, make_pair(poi, poi_open_time)); 
                    }

                    if (knn_tmp.size() > k_max) knn_tmp.resize(k_max);
                    
                    // Jump tt to next avaliable one
                    if (poi > -1) {
                        new_knn.emplace_back(tt[i_tt].first, knn_tmp);
                        i_tt++;
                    } else {
                        while (tt[i_tt].second <= knn[i_knn].first && i_tt < tt.size()) {
                            i_tt++;
                        }
                        
                        new_knn.emplace_back(tt[i_tt-1].first, knn_tmp);
                        if (i_tt == tt.size()) break;
                    }
                    
                    if (i_tt == tt.size()) break;                   
                }
            }

            if (poi > -1) {
                while (i_tt < tt.size()) {   // if w is a poi, add new latest poi_knn_lists
                    auto poi_open_time = get_opening_arrival_time(tt[i_tt].second, opening_hour);
                    if (poi_open_time == INT32_MAX) {
                        i_tt++;
                    } else {
                        vector<pair<int, int>> new_knn_td;
                        new_knn_td.emplace_back(poi, poi_open_time);
                        new_knn.emplace_back(tt[i_tt].first, new_knn_td);
                        i_tt++;
                    }
                }
            }
            return new_knn;
        }

        template<class C1>
        static int get_opening_arrival_time(const int ta, const C1 &opening_hour) {
            if (opening_hour.size() == 0) return ta;
            for (const auto& interval : opening_hour) {
                // if within opening hour
                if (ta >= interval.first && ta <= interval.second) {
                    return ta;
                }
                // if before an opening hour
                if (ta < interval.first) {
                    return interval.first;
                }
            }
            // if not open since now, return INT32_MAX
            return INT32_MAX;
        }

        // Combine kNN from down to root
        template<class C1, class C2>
        static void combine_knn_vec(C1 &knn_own, const C2 &knn_received, const int v_size, const int k_max) {
            vector<pair<int, vector<pair<int, int>>>> result;

            std::vector<std::pair<int, int>> knn_previous;
            auto rcv_back = knn_received.rbegin();
            auto own_back = knn_own.rbegin();

            while (rcv_back != knn_received.rend() and own_back != knn_own.rend()) {
                if (rcv_back->first > own_back->first) { // generate and store the knn_td depart at rcv_back->first
                    // merge knn_previous and rcv_back->second
                    auto knn_td_new = merge_2knn(rcv_back->second, knn_previous, v_size, k_max);
                    result.emplace_back(rcv_back->first, knn_td_new);
                    knn_previous = knn_td_new;
                    rcv_back++;
                } else if (rcv_back->first < own_back->first) { // generate and store the knn_td depart at own_back->first
                    // merge knn_previous and own_back->second
                    auto knn_td_new = merge_2knn(own_back->second, knn_previous, v_size, k_max);
                    result.emplace_back(own_back->first, knn_td_new);
                    knn_previous = knn_td_new;
                    own_back++;
                } else { // merge, generate and store the knn_td depart at own_back/rcv_back->first
                    // merge knn_previous and rcv_back->second and own_back->second
                    auto knn_td_new = merge_2knn(own_back->second, rcv_back->second, v_size, k_max);
                    knn_td_new = merge_2knn(knn_previous, knn_td_new, v_size, k_max);
                    result.emplace_back(own_back->first, knn_td_new);
                    knn_previous = knn_td_new;
                    rcv_back++;
                    own_back++;
                }
            }

            while (rcv_back != knn_received.rend()) {
                auto knn_td_new = merge_2knn(rcv_back->second, knn_previous, v_size, k_max);
                result.emplace_back(rcv_back->first, knn_td_new);
                knn_previous = knn_td_new;
                rcv_back++;
            }

            while (own_back != knn_own.rend()) {
                auto knn_td_new = merge_2knn(own_back->second, knn_previous, v_size, k_max);
                result.emplace_back(own_back->first, knn_td_new);
                knn_previous = knn_td_new;
                own_back++;
            }

            reverse(result.begin(), result.end());
            swap(knn_own, result);
        }

        // Combine kNN from root to down
        template<class C1, class C2>
        static void combine_knn_vec(C1 &knn_own, const C2 &knn_received, const int owner, const int v_size, const int k_max) {
            vector<pair<int, vector<pair<int, int>>>> result;

            std::vector<std::pair<int, int>> knn_previous;
            auto rcv_back = knn_received.rbegin();
            auto own_back = knn_own.rbegin();

            while (rcv_back != knn_received.rend() and own_back != knn_own.rend()) {
                if (rcv_back->first > own_back->first) { // generate and store the knn_td depart at rcv_back->first
                    // merge knn_previous and rcv_back->second
                    auto knn_td_new = merge_2knn(rcv_back->second, knn_previous, owner, v_size, k_max);
                    result.emplace_back(rcv_back->first, knn_td_new); // avoid using makepair
                    knn_previous = knn_td_new;
                    rcv_back++;
                } else if (rcv_back->first < own_back->first) { // generate and store the knn_td depart at own_back->first
                    // merge knn_previous and own_back->second
                    auto knn_td_new = merge_2knn(own_back->second, knn_previous, owner, v_size, k_max);
                    result.emplace_back(own_back->first, knn_td_new);
                    knn_previous = knn_td_new;
                    own_back++;
                } else { // merge, generate and store the knn_td depart at own_back/rcv_back->first
                    // merge knn_previous and rcv_back->second and own_back->second
                    auto knn_td_new = merge_2knn(own_back->second, rcv_back->second, owner, v_size, k_max);
                    knn_td_new = merge_2knn(knn_previous, knn_td_new, owner, v_size, k_max);
                    result.emplace_back(own_back->first, knn_td_new);
                    knn_previous = knn_td_new;
                    rcv_back++;
                    own_back++;
                }
            }

            while (rcv_back != knn_received.rend()) {
                auto knn_td_new = merge_2knn(rcv_back->second, knn_previous, owner, v_size, k_max);
                result.emplace_back(rcv_back->first, knn_td_new);
                knn_previous = knn_td_new;
                rcv_back++;
            }

            while (own_back != knn_own.rend()) {
                auto knn_td_new = merge_2knn(own_back->second, knn_previous, owner, v_size, k_max);
                result.emplace_back(own_back->first, knn_td_new);
                knn_previous = knn_td_new;
                own_back++;
            }

            reverse(result.begin(), result.end());
            swap(knn_own, result);
        }

        // Merge two knn_td, Down to Top
        template<class C1, class C2>
        static std::vector<std::pair<int, int>> merge_2knn(C1 &knn1, C2 &knn2, int v_size, int k_max) {
            std::vector<bool> poi_own(v_size, false);
            std::vector<std::pair<int, int>> result;
            int ptr1 = 0, ptr2 = 0;
            while (ptr1 < knn1.size() and ptr2 < knn2.size()) {
                if (result.size() == k_max) return result;
                if (poi_own[knn1[ptr1].first]) {
                    ptr1++;
                    continue;
                } else if (poi_own[knn2[ptr2].first]) {
                    ptr2++;
                    continue;
                }

                if (knn1[ptr1].second < knn2[ptr2].second) {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;
                    ptr1++;
                } else if (knn1[ptr1].second > knn2[ptr2].second) {
                    result.emplace_back(knn2[ptr2]);
                    poi_own[knn2[ptr2].first] = true;
                    ptr2++;
                } else {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;

                    if (!poi_own[knn2[ptr2].first]) {
                        result.emplace_back(knn2[ptr2]);
                        poi_own[knn2[ptr2].first] = true;
                    }
                    ptr1++;
                    ptr2++;
                }
            }

            while (ptr1 < knn1.size()) {
                if (result.size() == k_max) return result;
                if (!poi_own[knn1[ptr1].first]) {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;
                }
                ptr1++;
            }

            while (ptr2 < knn2.size()) {
                if (result.size() == k_max) return result;
                if (!poi_own[knn2[ptr2].first]) {
                    result.emplace_back(knn2[ptr2]);
                    poi_own[knn2[ptr2].first] = true;
                }
                ptr2++;
            }

            return result;
        }

        // Merge two knn_td, Top to Down
        template<class C1, class C2>
        static std::vector<std::pair<int, int>> merge_2knn(C1 &knn1, C2 &knn2, int owner, int v_size, int k_max) {
            std::vector<bool> poi_own(v_size, false);
            std::vector<std::pair<int, int>> result;
            int ptr1 = 0, ptr2 = 0;
            while (ptr1 < knn1.size() and ptr2 < knn2.size()) {
                if (result.size() == k_max) return result;
                if (poi_own[knn1[ptr1].first] or knn1[ptr1].first == owner) {
                    ptr1++;
                    continue;
                } else if (poi_own[knn2[ptr2].first] or knn2[ptr2].first == owner) {
                    ptr2++;
                    continue;
                }

                if (knn1[ptr1].second < knn2[ptr2].second) {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;
                    ptr1++;
                } else if (knn1[ptr1].second > knn2[ptr2].second) {
                    result.emplace_back(knn2[ptr2]);
                    poi_own[knn2[ptr2].first] = true;
                    ptr2++;
                } else {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;

                    if (!poi_own[knn2[ptr2].first]) {
                        result.emplace_back(knn2[ptr2]);
                        poi_own[knn2[ptr2].first] = true;
                    }
                    ptr1++;
                    ptr2++;
                }
            }

            while (ptr1 < knn1.size()) {
                if (result.size() == k_max) return result;
                if (!poi_own[knn1[ptr1].first] and knn1[ptr1].first != owner) {
                    result.emplace_back(knn1[ptr1]);
                    poi_own[knn1[ptr1].first] = true;
                }
                ptr1++;
            }

            while (ptr2 < knn2.size()) {
                if (result.size() == k_max) return result;
                if (!poi_own[knn2[ptr2].first] and knn2[ptr2].first != owner) {
                    result.emplace_back(knn2[ptr2]);
                    poi_own[knn2[ptr2].first] = true;
                }
                ptr2++;
            }
            return result;
        }

        static vector<int> scc_detection(const graph_transportation &g) {
            queue<int> Q;
            int sccid = -1;
            vector<int> scc(g.vertices.size(), -1);
            for (int i = 0; i < g.vertices.size(); ++i) {
                if (scc[i] == -1) {
                    sccid++;

                    Q.push(i);
                    scc[i] = sccid;
                    while (!Q.empty()) {
                        int v = Q.front();
                        Q.pop();
                        for (const auto &e : g.vertices[v].inb) {
                            if (scc[e.dst] == -1) {
                                scc[e.dst] = sccid;
                                Q.push(e.dst);
                            }
                        }
                        for (const auto &e : g.vertices[v].onb) {
                            if (scc[e.dst] == -1) {
                                scc[e.dst] = sccid;
                                Q.push(e.dst);
                            }
                        }
                    }
                }
            }
            return scc;
        }

        static void pre_process(graph_transportation &g) {
            for (int i = 0; i < g.vertices.size(); ++i) {
                int k = 0;
                while (k < g.vertices[i].onb.size()) {
                    if (g.vertices[i].onb[k].timeTable.empty()) {
                        swap(g.vertices[i].onb[k], g.vertices[i].onb.back());
                        g.vertices[i].onb.pop_back();
                    } else
                        k++;
                }
                k = 0;
                while (k < g.vertices[i].inb.size()) {
                    if (g.vertices[i].inb[k].timeTable.empty()) {
                        swap(g.vertices[i].inb[k], g.vertices[i].inb.back());
                        g.vertices[i].inb.pop_back();
                    } else
                        k++;
                }
            }

            //counting
            unordered_map<int, int> sccid2cnt;
            auto scc = scc_detection(g);
            for (int i = 0; i < scc.size(); ++i) { sccid2cnt[scc[i]]++; }
            //find max scc
            pair<int, int> max_scc2cnt{1, 0};
            for (auto kv : sccid2cnt) {
                if (kv.second > max_scc2cnt.second) max_scc2cnt = kv;
            }
            //reassign vid
            int vid = 0;
            vector<int> newvid(scc.size(), -1);
            for (int i = 0; i < scc.size(); ++i) {
                if (scc[i] == max_scc2cnt.first) { newvid[i] = vid++; }
            }
    
            //change graph
            int n = vid;
            for (int i = 0; i < g.vertices.size(); ++i) {
                if (newvid[i] != -1) {
                    for (auto &dsttt : g.vertices[i].onb) { dsttt.dst = newvid[dsttt.dst]; }
                    for (auto &dsttt : g.vertices[i].inb) { dsttt.dst = newvid[dsttt.dst]; }
                    swap(g.vertices[i], g.vertices[newvid[i]]);
                }
            }
            g.vertices.resize(n);

            //sort & prune timetables on edges
            for (int i = 0; i < g.vertices.size(); ++i) {

                for (auto &dsttt : g.vertices[i].onb) {
                    if (dsttt.timeTable.empty()) { assertf(!dsttt.timeTable.empty(), "timetable size is 0"); }
                    utils::algs::pruning_tt_inplace(dsttt.timeTable);
                }
                for (auto &dsttt : g.vertices[i].inb) {
                    if (dsttt.timeTable.empty()) { assertf(!dsttt.timeTable.empty(), "timetable size is 0"); }
                    utils::algs::pruning_tt_inplace(dsttt.timeTable);
                }
            }
        }

        static bool tt_equal(const vector<pair<int, int>> &a, const vector<pair<int, int>> &b) {
            if (a.size() != b.size()) return false;
            for (int i = 0; i < a.size(); ++i) {
                if (a[i] != b[i]) return false;
            }
            return true;
        }

        static pair<int, int> get_timestamp_range(const graph_transportation &gt) {
            int mints = numeric_limits<int>::max();
            int maxts = numeric_limits<int>::min();

            for (auto const &v : gt.vertices) {
                for (auto const &e : v.onb) {
                    for (auto const &p : e.timeTable) {
                        mints = min({p.first, p.second, mints});
                        maxts = max({p.first, p.second, maxts});
                    }
                }
                for (auto const &e : v.inb) {
                    for (auto const &p : e.timeTable) {
                        mints = min({p.first, p.second, mints});
                        maxts = max({p.first, p.second, maxts});
                    }
                }
            }
            return {mints, maxts};
        }

    };

    graph_transportation loading_graph_bin(const std::string &path) {
        double stime = wall_time();
        graph_transportation GT;

        using namespace std;
        auto ifile = read_file(path);
        int s, t, st, at;
        int maxs = 0, maxt = 0, maxst = 0, maxat = 0;
        int out_edge = 0;
        vector<unordered_map<int, set<pair<int, int>>>> g_local;
        int n = 0;
        while (true) {
            read(ifile, s);
            read(ifile, t);
            read(ifile, st);
            read(ifile, at);
            if (feof(ifile)) break;
            maxs = max(maxs, s);
            maxt = max(maxt, t);
            n = max(n, max(maxs, maxt) + 1);
            g_local.resize(n);
            g_local[s][t].emplace(st, at);
        }
        fclose(ifile);

        GT.vertices.resize(n);

        for (int i = 0; i < g_local.size(); ++i) {
            for (auto &kv : g_local[i]) {
                GT.vertices[i].onb.emplace_back(kv.first);
                GT.vertices[kv.first].inb.emplace_back(i);
                out_edge += kv.second.size();
                for (auto &tt : kv.second) { 
                    GT.vertices[i].onb.back().timeTable.emplace_back(tt.first, tt.second); 
                }
                GT.vertices[kv.first].inb.back().timeTable = GT.vertices[i].onb.back().timeTable;
            }
        }
        double etime = wall_time();
        mlog("loading graph cost %f secs", etime - stime);

        return GT;
    }

}// namespace utils
#endif//EXP_CODE_TDT_MODEL_H_