# Source code for TNN-Index

The experiments are conducted in Linux with gcc 9.4.0 and python 3.10

## Dataset

A small toy dataset is provided in the `datasets/example` folder.

## To run, including indexing and query

```sh run.sh```

```shell
#! /bin/bash -e
echo "Compiling.."
g++ -std=c++17 -O2 -w indexing.cpp -o indexing
g++ -std=c++17 -O2 -w query.cpp -o query

echo "Indexing"
./indexing -p datasets/example -k 3 -d 005 -c N -o N

echo "Querying"
./query -p datasets/example -k 3 -d 005 -c N -o N
```
