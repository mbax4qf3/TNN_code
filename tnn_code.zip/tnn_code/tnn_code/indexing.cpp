#include <unistd.h>
#include <string>
#include "header.h"
#include "ptl.h"

using namespace std;

int main(int argc, char *argv[]) {
    string folder;
    int k_max = 20; 
    string poi_density = "005"; 
    string compress_flag = "Y";
    string opening_flag = "N";
    vector<string> density_list = {"001", "005", "01", "05", "10"};

    int option = -1;
    while (-1 != (option = getopt(argc, argv, "p:k:d:c:o:"))) {
        switch (option) {
            case 'p':
                folder = optarg;
                if (folder.empty()) {
                    printf("Please specify the folder of the dataset using -p\n");
                    return 0;
                }
                break;
            case 'k':
                k_max = stoi(optarg);
                break;
            case 'd':
                poi_density = optarg;
                if (find(density_list.begin(), density_list.end(), poi_density) == density_list.end()) {
                    printf("Please specify the poi density -d in [\"001\", \"005\", \"01\", \"05\", \"10\"]\n");
                    return 0;
                }
                break;
            case 'c':
                compress_flag = optarg;
                if (compress_flag != "Y" && compress_flag != "N") {
                    printf("Please specify whether compress the index using -c\n");
                    return 0;
                }
                break;
            case 'o':
                opening_flag = optarg;
                if (opening_flag != "Y" && opening_flag != "N") {
                    printf("Please specify whether support opening hour the index using -o\n");
                    return 0;
                }
                break;
        }
    }

    string graph_path = folder + "/graph.bin";
    string poi_path = folder + "/poi_0d" + poi_density + ".txt";
    string poi_opening_hour_path = folder + "/poi_0d" + poi_density + "_opening_hour.txt";
    string ptl_index_path = folder + "/index.ptl";
    string knn_index_path = folder + "/knn_index_" + to_string(k_max) + "_" + poi_density +".ptl"; // knn_index_kmax_poiDesity, e.g., knn_index_30_01 (kmax 30, poi density 1%)
    string knn_comp_index_path = folder + "/knnComp_index_" + to_string(k_max) + "_" + poi_density +".ptl";

    ptl::ptl_algs alg(graph_path);

    alg.load_poi(poi_path);

    if (opening_flag == "Y") {
        alg.load_opening_hour(poi_opening_hour_path); 
        knn_index_path = folder + "/knn_index_" + to_string(k_max) + "_" + poi_density +"_O.ptl";
        knn_comp_index_path = folder + "/knnComp_index_" + to_string(k_max) + "_" + poi_density +"_O.ptl";
    }

    alg.indexing(k_max, opening_flag);
    
    if (compress_flag == "Y") alg.compress_knn_index();

    if (compress_flag == "Y") alg.store_compressed_knn_idx(knn_comp_index_path);
    else if (compress_flag == "N") alg.store_knn_idx(knn_index_path);

    return 0;
}