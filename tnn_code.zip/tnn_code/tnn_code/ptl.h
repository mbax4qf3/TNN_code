// #endif//EXP_CODE_TDT_TDT_ptl_H_

#ifndef EXP_CODE_TDT_TDT_ptl_H_
#define EXP_CODE_TDT_TDT_ptl_H_

#include <queue>
#include <unordered_map>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <limits>
#include <fstream>

#include "header.h"
#include "file_io.h"
#include "utils.h"

namespace ptl {

    struct treeNode {
        treeNode() : pnodeid(-1), cnodeid(), edges(), pos(), 
        knn_list(), compressed_knn_poi_list(), compressed_knn_arrT_list() {}

        int height_topdown;
        int pnodeid;
        std::vector<unsigned int> cnodeid;
        vector<pair<unsigned int, utils::undirected_tt_attr>> edges;

        // data structure for ptl index
        vector<int> pos;

        // data stucture for knn index
        vector<pair<int, vector<pair<int, int>>>> knn_list;
        vector<pair<int, vector<int>>> compressed_knn_poi_list;
        vector<vector<pair<int, vector<int>>>> compressed_knn_arrT_list;
    };

    struct Vertex {
        int id;
        int distance;

        Vertex(int id, int distance) : id(id), distance(distance) {}

        bool operator>(const Vertex& other) const {
            return distance > other.distance;
        }

        bool operator<(const Vertex& other) const {
            return distance < other.distance;
        }
    };

    class ptl_algs {
    public:
        ptl_algs() = default;

        explicit ptl_algs(const string &path) {
            gt = utils::loading_graph_bin(path);
            utils::algs::pre_process(gt);
        }

        explicit ptl_algs(utils::graph_transportation &&gtp) {
            gt = std::move(gtp);
            utils::algs::pre_process(gt);
        }

        void reduce(int k_max, string opening_flag) {
            mlog("graph reduction...");
            double acctime_down_top = 0.0;
            vector<int> v_process_sequence;

            //init shortcuts with the graph.
            vector<unordered_map<unsigned int, utils::undirected_tt_attr>> shortcuts(gt.vertices.size());
            for (int s = 0; s < gt.vertices.size(); ++s) {
                for (unsigned int i = 0; i < gt.vertices[s].onb.size(); ++i) {
                    utils::edge_timetable &oe = gt.vertices[s].onb[i];
                    shortcuts[s][oe.dst].ott = oe.timeTable; // the timetable from s to dst
                }
                for (unsigned int i = 0; i < gt.vertices[s].inb.size(); ++i) {
                    auto &ie = gt.vertices[s].inb[i];
                    shortcuts[s][ie.dst].itt = ie.timeTable; // the timetable from dst to s
                }
            }

            // build bucket for the (priority) queue.
            vector<vector<int>>
                    degree2nodeQ; // degree2nodeQ[degree] = {vid1,vid2,...}, where degree is the degree of the vertex, vid1,vid2,... are the vertex ids with the same degree.
            vector<pair<int, int>> vPosition(gt.vertices.size()); // (degree,idx)

            for (int vid = 0; vid < gt.vertices.size(); ++vid) {
                // resize the degree2nodeQ if necessary
                int degree = shortcuts[vid].size();
                if (degree >= degree2nodeQ.size()) { degree2nodeQ.resize(degree + 1); }
                // insert the vertex into the queue, and record its position
                vPosition[vid] = make_pair(degree, degree2nodeQ[degree].size()); // (degree, pos in deg2node[degree])
                degree2nodeQ[degree].push_back(vid);
            }

            // prepare data structures for vertex reduction.
            int vorder = 0; // the order of the vertex during tree decomposition, from 0 to n-1.
            vertexOrder.resize(gt.vertices.size(), -1); // vertexOrder[vid] = vorder

            int mindegree = 0; // the minimum degree of the remaining graph.
            treeNodes.resize(gt.vertices.size());

            int reduced_cnt = 0; // the number of vertices reduced for the current degree threshold.
            unsigned int threshold_k = 0; // current degree threshold, increase by 1 when mindegree > threshold_k.
            mindegree = 0;

            // Reduction
            double cur_time = wall_time();
            while (true) {
                // find a vertex with minimum degree
                while (mindegree < degree2nodeQ.size() && degree2nodeQ[mindegree].empty()) {
                    if (mindegree == threshold_k) {
                        if (reduced_cnt != 0) {
                            mlog("reducting %u...", mindegree);
                            reduced_cnt = 0;
                        }
                        threshold_k++;
                    }
                    mindegree++;
                }
                if (degree2nodeQ.size() == mindegree) break; // no more vertex to reduce.

                reduced_cnt++;
                int vid = degree2nodeQ[mindegree].back();
                degree2nodeQ[mindegree].pop_back();
                vertexOrder[vid] = vorder++; // set the order of the vertex, from 0 to n-1.

                // start vertex reduction
                unordered_map<unsigned int, utils::undirected_tt_attr> &v = shortcuts[vid];
                v_process_sequence.push_back(vid);
                if (wall_time() - cur_time > 1800) {
                    mlog("Reducing... order=%u Gdeg=%d deg=%lu...", vorder, mindegree, v.size());
                    cur_time = wall_time();
                }

                // find the neighbors that are not reduced yet and add them to vtmp
                vector<std::pair<unsigned int, utils::undirected_tt_attr>> vtmp;
                for (auto &kv: v) {
                    if (vertexOrder[kv.first] == -1) { vtmp.emplace_back(kv.first, std::move(kv.second)); }
                }

                // kNN index bottom to top
                for (int x = 0; x < vtmp.size(); x++) {
                    auto nbr = vtmp[x];
                    int poi_vid = poi_list[vid] == 1 ? vid : -1;
                    if (opening_flag == "N") {
                        utils::algs::combine_knn_vec(treeNodes[nbr.first].knn_list, 
                            utils::algs::join_tt_knn_vec(nbr.second.itt, treeNodes[vid].knn_list, poi_vid, k_max), gt.vertices.size(), k_max);
                    } else {
                        utils::algs::combine_knn_vec(treeNodes[nbr.first].knn_list, 
                            utils::algs::join_tt_knn_vec(nbr.second.itt, treeNodes[vid].knn_list, poi_vid, poi_opening_hours[poi_vid], k_max), gt.vertices.size(), k_max);
                    }
                }

                vector<int> neighbor_degree_increase_cnt(vtmp.size(), -1); // record the degree to be increased or decreased for each neighbor
                // add short cuts
                for (unsigned int i = 0; i < vtmp.size(); ++i) {
                    for (unsigned int j = i + 1; j < vtmp.size(); ++j) {
                        // after reducing v, check which v's neighbors are not neighborhood
                        if (shortcuts[vtmp[i].first].find(vtmp[j].first) == shortcuts[vtmp[i].first].end()) {
                            neighbor_degree_increase_cnt[i]++;
                            neighbor_degree_increase_cnt[j]++;
                        }

                        utils::algs::combine_tt_inplace(shortcuts[vtmp[i].first][vtmp[j].first].ott,
                                                        utils::algs::join_tt(vtmp[i].second.itt, vtmp[j].second.ott));
                        utils::algs::combine_tt_inplace(shortcuts[vtmp[i].first][vtmp[j].first].itt,
                                                        utils::algs::join_tt(vtmp[j].second.itt, vtmp[i].second.ott));

                        shortcuts[vtmp[j].first][vtmp[i].first].ott = shortcuts[vtmp[i].first][vtmp[j].first].itt;
                        shortcuts[vtmp[j].first][vtmp[i].first].itt = shortcuts[vtmp[i].first][vtmp[j].first].ott;
                    }
                }

                // update the degree2nodeQ and the associated data structures vPosition
                for (unsigned int i = 0; i < vtmp.size(); ++i) {
                    if (neighbor_degree_increase_cnt[i] != 0) {
                        unsigned int &x = vtmp[i].first;
                        pair<int, int> &p = vPosition[x]; // (degree,idx)
                        // swap and delete
                        degree2nodeQ[p.first][p.second] = degree2nodeQ[p.first].back();
                        vPosition[degree2nodeQ[p.first].back()].second = p.second;
                        degree2nodeQ[p.first].pop_back();
                        // place in a new position
                        p.first += static_cast<unsigned int>(neighbor_degree_increase_cnt[i]);
                        if (p.first >= degree2nodeQ.size()) {
                            degree2nodeQ.resize(p.first + 1);
                        } // increase the size of degree2nodeQ if necessary
                        mindegree = min(mindegree, p.first);
                        p.second = degree2nodeQ[p.first].size();
                        degree2nodeQ[p.first].push_back(x);
                    }
                }

                // building tnodes
                swap(treeNodes[vid].edges, vtmp);
            }

            // propogate kNN from root down to each vertex
            for (int ptr_v = v_process_sequence.size()-2; ptr_v >= 0; ptr_v--) {              
                auto cur_V = v_process_sequence[ptr_v];
                for (auto v_nbrs:treeNodes[cur_V].edges) {
                    auto cur_v_nbr = v_nbrs.first;
                    auto cur_v_tt = v_nbrs.second;
                    int poi_v_nbr = poi_list[cur_v_nbr] == 1 ? cur_v_nbr : -1;
                    if (opening_flag == "N") {
                        utils::algs::combine_knn_vec(treeNodes[cur_V].knn_list, 
                            utils::algs::join_tt_knn_vec(cur_v_tt.ott, treeNodes[cur_v_nbr].knn_list, poi_v_nbr, k_max), cur_V, gt.vertices.size(), k_max);
                    } else {
                        utils::algs::combine_knn_vec(treeNodes[cur_V].knn_list, 
                            utils::algs::join_tt_knn_vec(cur_v_tt.ott, treeNodes[cur_v_nbr].knn_list, poi_v_nbr, poi_opening_hours[poi_v_nbr], k_max), cur_V, gt.vertices.size(), k_max);
                    }
                }
            }
        }

        void indexing(int k_max, string opening_flag) {
            mlog("start indexing...");
            double stime, etime;
            stime = wall_time();
            reduce(k_max, opening_flag);
            etime = wall_time();
            mlog("finish indexing in %f seconds...", etime - stime);
        }

        void compress_knn_index() {
            double stime, etime;
            stime = wall_time();

            int tNid;
            for (tNid = 0; tNid < treeNodes.size(); tNid++) {
                auto knn_idx = treeNodes[tNid].knn_list;
                int start_ptr = 0, run_ptr = 0;
                while (start_ptr < knn_idx.size() && run_ptr < knn_idx.size()) {
                    
                    start_ptr = run_ptr;
                    
                    vector<int> start_pois(knn_idx[start_ptr].second.size());
                    vector<int> start_arrT(knn_idx[start_ptr].second.size());

                    transform(knn_idx[start_ptr].second.begin(), knn_idx[start_ptr].second.end(), 
                        start_pois.begin(), [](auto const& p){ return p.first; });
                    transform(knn_idx[start_ptr].second.begin(), knn_idx[start_ptr].second.end(), 
                        start_arrT.begin(), [](auto const& p){ return p.second; });

                    reorder_knn(start_pois, start_arrT);
                    vector<int> cur_pois(start_pois.begin(), start_pois.end());
                    vector<int> cur_arrT(start_arrT.begin(), start_arrT.end());
                    vector<pair<int, vector<int>>> compress_knn_single;

                    while (start_pois == cur_pois && run_ptr < knn_idx.size()) {

                        if (start_ptr == run_ptr || cur_arrT != compress_knn_single.back().second) {
                            /*mk*/
                            compress_knn_single.emplace_back(knn_idx[run_ptr].first, cur_arrT);// first_full_rest_delta);
                        } else {
                            compress_knn_single.back() = make_pair(knn_idx[run_ptr].first, cur_arrT);// first_full_rest_delta);
                        }
                        
                        run_ptr++;
                        if (run_ptr >= knn_idx.size()) break;

                        // get next pois
                        cur_pois.resize(knn_idx[run_ptr].second.size());
                        transform(knn_idx[run_ptr].second.begin(), knn_idx[run_ptr].second.end(), 
                            cur_pois.begin(), [](auto const& p){ return p.first; });
                        // get next tas
                        cur_arrT.resize(knn_idx[run_ptr].second.size());
                        transform(knn_idx[run_ptr].second.begin(), knn_idx[run_ptr].second.end(), 
                            cur_arrT.begin(), [](auto const& p){ return p.second; });
                        
                        reorder_knn(cur_pois, cur_arrT);
                    }

                    auto latest_departT = compress_knn_single.back().first;
                    treeNodes[tNid].compressed_knn_poi_list.emplace_back(latest_departT, start_pois);
                    treeNodes[tNid].compressed_knn_arrT_list.emplace_back(compress_knn_single);
                }
            }

            etime = wall_time();
            mlog("Compress knn.idx cost %f seconds.", etime - stime);
        }

        void reorder_knn(vector<int> &points, const vector<int> &times) {
            std::vector<int> indices(points.size());
            for (size_t i = 0; i < points.size(); i++) {
                indices[i] = i; 
            }

            std::sort(indices.begin(), indices.end(), [&](int a, int b) {
                if (times[a] == times[b]) {
                    return points[a] < points[b];
                }
                return times[a] < times[b];
            });

            std::vector<int> sortedPoints(points.size());
            for (size_t i = 0; i < indices.size(); i++) {
                sortedPoints[i] = points[indices[i]];
            }
            points = sortedPoints;
        }

        std::size_t store_knn_idx(const string &path) {
            double stime, etime;
            stime = wall_time();
            mlog("store kNN index to %s", path.c_str());
            auto file_p = write_file(path);
            int n = gt.vertices.size();
            write(file_p, n);
            write(file_p, poi_list);
            for (int i = 0; i < gt.vertices.size(); ++i) {
                write(file_p, treeNodes[i].knn_list);
            }
            fclose(file_p);
            etime = wall_time();

            std::size_t filesize = get_filesize(path);
            mlog("store knn.idx cost %f seconds. the index size is %lu bytes", etime - stime, filesize);
            return filesize;
        }

        std::size_t store_compressed_knn_idx(const string &path) {
            double stime, etime;
            stime = wall_time();
            mlog("store compressed kNN index to %s", path.c_str());
            auto file_p = write_file(path);
            int n = gt.vertices.size();
            write(file_p, n);
            write(file_p, poi_list);
            for (int i = 0; i < gt.vertices.size(); ++i) {
                // convert from int to unsigned short int
                vector<pair<int, vector<unsigned short int>>> converted;
                for (const auto& p : treeNodes[i].compressed_knn_poi_list) {
                    vector<unsigned short int> uShortVec(p.second.begin(), p.second.end());
                    converted.push_back({p.first, uShortVec});
                }
                // write
                write(file_p, converted);
                write(file_p, treeNodes[i].compressed_knn_arrT_list);
            }
            fclose(file_p);
            etime = wall_time();

            std::size_t filesize = get_filesize(path);
            mlog("store knn_comp.idx cost %f seconds. the index size is %lu bytes", etime - stime, filesize);
            return filesize;
        }

        bool load_knn_idx(const string &path) {
            double stime, etime;
            stime = wall_time();
            auto file_p = read_file(path, false);
            if (file_p == nullptr) return false;
            int n;
            read(file_p, n);
            read(file_p, poi_list);
            treeNodes.resize(n);
            for (int i = 0; i < n; ++i) {
                read(file_p, treeNodes[i].knn_list);
            }
            check_eof(file_p);
            etime = wall_time();
            mlog("load knn index cost %f seconds.", etime - stime);

            return true;
        }

        bool load_compressed_knn_idx(const string &path) {
            double stime, etime;
            stime = wall_time();
            auto file_p = read_file(path, false);
            if (file_p == nullptr) return false;
            int n;
            read(file_p, n);
            read(file_p, poi_list);
            treeNodes.resize(n);
            for (int i = 0; i < n; ++i) {
                // read
                vector<pair<int, vector<unsigned short int>>> converted;
                read(file_p, converted);
                // convert from unsigned short int to int
                for (const auto& p : converted) {
                    vector<int> intVec(p.second.begin(), p.second.end());
                    treeNodes[i].compressed_knn_poi_list.push_back({p.first, intVec});
                }
                // read
                read(file_p, treeNodes[i].compressed_knn_arrT_list);
            }
            check_eof(file_p);
            etime = wall_time();
            mlog("load knn_comp.idx cost %f seconds.", etime - stime);

            return true;
        }

        bool load_poi(const string &path) {
            double stime, etime;
            stime = wall_time();
            auto file_p = read_file(path, false);
            if (file_p == nullptr) return false;

            int poi_n, N = 10;
            char cur_line[N];
            fgets(cur_line, N, file_p); // read N-1 chars to cur_line, the first line is the number of POIs
            poi_n = stoi(cur_line);
            poi_list.resize(gt.vertices.size(), -1);
            short2poi.resize(poi_n);
            poi2short.resize(gt.vertices.size());
            unsigned short int p2v = 0;

            while( fgets(cur_line, N, file_p) != NULL ) {
                poi_list[stoi(cur_line)] = 1;
                poi_vertices.push_back(stoi(cur_line));
                short2poi[p2v] = stoi(cur_line);
                poi2short[stoi(cur_line)] = p2v;
                p2v++;
            }

            etime = wall_time();
            return true;
        }

        bool load_opening_hour(const string &path) {
            double stime, etime;
            stime = wall_time();

            poi_opening_hours.resize(gt.vertices.size());
            for (auto poi:poi_vertices) {
                if (poi % 4 == 0) {
                    poi_opening_hours[poi] = {{9, 15}};
                } else if (poi % 5 == 0) {
                    poi_opening_hours[poi] = {{2, 5}, {7, 9}};
                } else {
                    poi_opening_hours[poi] = {};
                }
            }

            etime = wall_time();
            return true;
        }

        vector<pair<int, int>> query_knn_index_vector(int v, int departT, int k, string open_flag) {
            vector<pair<int, int>> result; 
            int found = 0;
            int tmp_v_open = 0;
            bool added = false;
            if (open_flag == "N") {
                if (poi_list[v] == 1) { 
                    result.emplace_back(v,departT); 
                    found = 1; 
                }
            } else {
                if (poi_list[v] == 1) { 
                    tmp_v_open = utils::algs::get_opening_arrival_time(departT, poi_opening_hours[v]); 
                }
            }

            auto it = lower_bound(treeNodes[v].knn_list.begin(), treeNodes[v].knn_list.end(), departT,
                        [](const auto& a, const auto& b) { return a.first < b; });
            if (it != treeNodes[v].knn_list.end()) {
                auto knn_departT = it->second;
                for (int ki = 0; ki < knn_departT.size(); ki++) {
                    if (open_flag == "Y" && poi_list[v] == 1 && !added) {
                        if (tmp_v_open <= knn_departT[ki].second) {
                            result.emplace_back(v, tmp_v_open);
                            added = true;
                            found++;
                            if (found == k) return result;
                        }
                    }
                    result.emplace_back(knn_departT[ki]);
                    found++;
                    if (found == k) return result;
                }

                if (knn_departT.size() == 0 && open_flag == "Y" && poi_list[v] == 1 && tmp_v_open != INT32_MAX) {
                    result.emplace_back(v, tmp_v_open);
                }
            } else {
                if (open_flag == "Y" && poi_list[v] == 1 && tmp_v_open != INT32_MAX) {
                    result.emplace_back(v, tmp_v_open);
                }
            }

            return result;
        } 

        vector<pair<int, int>> query_compressed_knn_index_vector(int v, int departT, int k, string open_flag) {
            vector<pair<int, int>> result; 
            int found = 0;
            int tmp_v_open = 0;
            bool added = false;
            if (open_flag == "N") {
                if (poi_list[v] == 1) { 
                    result.emplace_back(v,departT); 
                    found = 1; 
                }
            } else {
                if (poi_list[v] == 1) { 
                    tmp_v_open = utils::algs::get_opening_arrival_time(departT, poi_opening_hours[v]); 
                }
            }

            auto it = lower_bound(treeNodes[v].compressed_knn_poi_list.begin(), treeNodes[v].compressed_knn_poi_list.end(), departT,
                        [](const auto& a, const auto& b) { return a.first < b; });
            if (it != treeNodes[v].compressed_knn_poi_list.end()) {
                int pos_index_poi = distance(treeNodes[v].compressed_knn_poi_list.begin(), it);

                auto it2 = lower_bound(treeNodes[v].compressed_knn_arrT_list[pos_index_poi].begin(), 
                        treeNodes[v].compressed_knn_arrT_list[pos_index_poi].end(), departT,
                        [](const auto& a, const auto& b) { return a.first < b; });
                int pos_index_arrT = distance(treeNodes[v].compressed_knn_arrT_list[pos_index_poi].begin(), it2);

                for (int ki = 0; ki < treeNodes[v].compressed_knn_poi_list[pos_index_poi].second.size(); ki++) {
                    if (open_flag == "Y" && poi_list[v] == 1 && !added) {
                        if (tmp_v_open <= treeNodes[v].compressed_knn_arrT_list[pos_index_poi][pos_index_arrT].second[ki]) {
                            result.emplace_back(v, tmp_v_open);
                            added = true;
                            found++;
                            if (found == k) return result;
                        }
                    }
                    result.emplace_back(treeNodes[v].compressed_knn_poi_list[pos_index_poi].second[ki],
                            treeNodes[v].compressed_knn_arrT_list[pos_index_poi][pos_index_arrT].second[ki]);
                    found++;
                    if (found == k) return result;
                }

                if (treeNodes[v].compressed_knn_poi_list[pos_index_poi].second.size() == 0 && open_flag == "Y" && poi_list[v] == 1 && tmp_v_open != INT32_MAX) {
                    result.emplace_back(v, tmp_v_open);
                }
            } else {
                if (open_flag == "Y" && poi_list[v] == 1 && tmp_v_open != INT32_MAX) {
                    result.emplace_back(v, tmp_v_open);
                }
            }

            return result;
        } 

        vector<pair<int, int>> dijkstra(int source, int t, int k) {
            vector<pair<int, int>> knn;
            vector<bool> confirmed(gt.vertices.size(), false); // store the confirmed v

            int knn_count = 0;
            vector<int> distances(gt.vertices.size(), numeric_limits<int>::max()); // used to store the latest shortest distance from source
            distances[source] = t; // init source with the depart time

            priority_queue<Vertex, vector<Vertex>, greater<Vertex>> pq; // pq with the top element has the smallest depart time (tt has been pruned and sorted)
            pq.push(Vertex(source, t));

            while (!pq.empty()) {
                Vertex curr = pq.top();
                pq.pop();
                if (confirmed[curr.id]) continue;
                confirmed[curr.id] = true;
                
                if (poi_list[curr.id] == 1) { // if current is a poi and |result| < k, find a knn
                    knn_count++;
                    knn.push_back(std::make_pair(curr.id, curr.distance));
                    if (knn_count == k) break; 
                }

                for (const auto& neighbor_tt : gt.vertices[curr.id].onb) { // for each neighbor
                    int neighborId = neighbor_tt.dst;

                    auto time_depart_arrival = lower_bound(neighbor_tt.timeTable.begin(), neighbor_tt.timeTable.end(), distances[curr.id],
                                      [](pair<int, int> datt, int td) { return datt.first < td; }); // find the smallest departTime from curr (no smaller than curr.distance) to neighbor
                    if (time_depart_arrival == neighbor_tt.timeTable.end()) continue;
                    auto arrivalTime = time_depart_arrival->second;
                    if (arrivalTime < distances[neighborId]) { // if find earlier arrival time, update the distance, push to the pq, update the path tracker
                        distances[neighborId] = arrivalTime;
                        pq.push(Vertex(neighborId, distances[neighborId]));
                    }
                }
            }

            return knn;
        }

        vector<pair<int, int>> dijkstra_op2(int source, int t, int k) {
            vector<pair<int, int>> knn;
            priority_queue<Vertex, vector<Vertex>, greater<Vertex>> knn_pq;
            vector<bool> confirmed(gt.vertices.size(), false);
            vector<int> distances(gt.vertices.size(), numeric_limits<int>::max());
            distances[source] = t;

            priority_queue<Vertex, vector<Vertex>, greater<Vertex>> pq;
            pq.push(Vertex(source, t));

            while (!pq.empty()) {
                Vertex curr = pq.top();
                pq.pop();

                if (confirmed[curr.id]) continue;
                confirmed[curr.id] = true;

                if (poi_list[curr.id] == 1) {
                    int openTime = utils::algs::get_opening_arrival_time(distances[curr.id], poi_opening_hours[curr.id]);
                    // if arriving during opening hours
                    if (openTime == distances[curr.id]) {
                        // add those wait_until_opening pois to knn if their ta <= openTime
                        while (!knn_pq.empty() && knn_pq.top().distance <= openTime) {
                            auto knn_pq_front = knn_pq.top(); 
                            knn_pq.pop();
                            knn.push_back(make_pair(knn_pq_front.id, knn_pq_front.distance));
                            if (knn.size() >= k) break;
                        }
                        // add itself
                        knn.push_back(make_pair(curr.id, openTime));
                        if (knn.size() >= k) break;
                    } else if (openTime != numeric_limits<int>::max()) {
                        knn_pq.push(Vertex(curr.id, openTime));
                    }
                }

                for (const auto& neighbor_tt : gt.vertices[curr.id].onb) {
                    int neighborId = neighbor_tt.dst;
                    if (confirmed[neighborId]) continue;

                    auto time_depart_arrival = lower_bound(neighbor_tt.timeTable.begin(), neighbor_tt.timeTable.end(), distances[curr.id],
                                        [](pair<int, int> datt, int td) { return datt.first < td; });

                    if (time_depart_arrival == neighbor_tt.timeTable.end()) continue;

                    auto departureTime = time_depart_arrival->first;
                    auto arrivalTime = time_depart_arrival->second;

                    if (arrivalTime < distances[neighborId]) {
                        distances[neighborId] = arrivalTime;
                        pq.push(Vertex(neighborId, distances[neighborId]));
                    }
                }
            }

            while (!knn_pq.empty() && knn.size() < k) {
                knn.push_back(make_pair(knn_pq.top().id,knn_pq.top().distance));
                knn_pq.pop();
            }
            if (knn.size() > k) knn.resize(k);
 
            return knn;
        }

        utils::graph_transportation *getG() { return &gt; }

        utils::graph_transportation gt;
        vector<int> vertexOrder;
        vector<treeNode> treeNodes;
        vector<int> rootVertices;
        vector<signed char> poi_list;
        vector<int> poi_vertices;
        vector<vector<pair<int, int>>> poi_opening_hours;
        vector<int> poi2short;
        vector<int> short2poi;
    };

}// namespace ptl

#endif//EXP_CODE_TDT_TDT_ptl_H_