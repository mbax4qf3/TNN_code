#!/usr/bin/python3.10

import os.path
import struct
from collections import namedtuple
import re
import argparse

dataset_folder = 'datasets/example/'

edges = [
    [6,1,6,8],
    [1,6,1,3],
    [6,3,3,4],
    [3,6,5,6],
    [3,6,8,9],
    [1,4,2,4],
    [1,4,4,6],
    [4,1,7,8],
    [3,4,5,6],
    [4,3,3,4],
    [4,3,7,8],
    [3,2,4,5],
    [3,2,8,9],
    [2,3,4,5],
    [4,7,3,4],
    [4,7,6,7],
    [7,4,4,5],
    [2,7,3,4],
    [7,2,4,5],
    [7,2,7,8],
    [2,5,5,8],
    [2,5,9,11],
    [5,2,1,3]
]
with open(os.path.join(dataset_folder, "graph.bin"), 'wb') as file:
    for e in edges:
        file.write(struct.pack('iiii', e[0], e[1], e[2], e[3]))
