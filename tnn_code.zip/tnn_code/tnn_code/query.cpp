#include <unistd.h>
#include <string>
#include "header.h"
#include "ptl.h"

using namespace std;

int main(int argc, char *argv[]) {
    string folder;
    int k_max = 20;
    string compress_flag = "Y";
    string poi_density = "005";
    string opening_flag = "N";

    int option = -1;
    while (-1 != (option = getopt(argc, argv, "p:k:d:c:o:"))) {
        switch (option) {
            case 'p':
                folder = optarg;
                if (folder.empty()) {
                    printf("Please specify the folder of the dataset using -p\n");
                    return 0;
                }
                break;
            case 'k':
                k_max = stoi(optarg);
                break;
            case 'd':
                poi_density = optarg;
                break;
            case 'c':
                compress_flag = optarg;
                if (compress_flag != "Y" && compress_flag != "N") {
                    printf("Please specify whether compress the index using -c\n");
                    return 0;
                }
                break;
            case 'o':
                opening_flag = optarg;
                if (opening_flag != "Y" && opening_flag != "N") {
                    printf("Please specify whether support opening hour the index using -o\n");
                    return 0;
                }
                break;
        }
    }

    string graph_path = folder + "/graph.bin";
    string poi_path = folder + "/poi_0d" + poi_density + ".txt";
    string poi_opening_hour_path = folder + "/poi_0d" + poi_density + "_opening_hour.txt";
    string knn_index_path = folder + "/knn_index_" + to_string(k_max) + "_" + poi_density +".ptl";
    string knn_comp_index_path = folder + "/knnComp_index_" + to_string(k_max) + "_" + poi_density +".ptl";

    ptl::ptl_algs alg(graph_path);
    alg.load_poi(poi_path);

    if (opening_flag == "Y") {
        alg.load_opening_hour(poi_opening_hour_path);
        knn_index_path = folder + "/knn_index_" + to_string(k_max) + "_" + poi_density +"_O.ptl";
        knn_comp_index_path = folder + "/knnComp_index_" + to_string(k_max) + "_" + poi_density +"_O.ptl";
    }

    if (compress_flag == "N") 
        alg.load_knn_idx(knn_index_path);
    else if (compress_flag == "Y") 
        alg.load_compressed_knn_idx(knn_comp_index_path);

    double stime, etime, dijTime = 0, idxTime = 0;
    int vq = 1;
    int td = 3; // td
    int k = 3;

    // INE
    stime = wall_time();
    vector<pair<int, int>> knn_dijk;
    if (opening_flag == "N") {
        knn_dijk = alg.dijkstra(vq, td, k);
    } else {
        knn_dijk = alg.dijkstra_op2(vq, td, k);
    }
    etime = wall_time();
    dijTime = (etime - stime);

    // TNN
    stime = wall_time();
    vector<pair<int, int>> knn_idx;
    if (compress_flag == "N") 
        knn_idx = alg.query_knn_index_vector(vq, td, k, opening_flag);
    else if (compress_flag == "Y") 
        knn_idx = alg.query_compressed_knn_index_vector(vq, td, k, opening_flag);
    etime = wall_time();
    idxTime = (etime - stime);

    mlog("Dij query cost %f microseconds.", dijTime);
    mlog("TNN query cost %f microseconds.", idxTime);

    return 0;
}