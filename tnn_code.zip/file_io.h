#ifndef EXP_CODE_LIBS_FILE_IO_H_
#define EXP_CODE_LIBS_FILE_IO_H_
#include <filesystem>
#include <string>
#include <type_traits>

FILE *write_file(const std::string &path, bool exit_on_failure = true) {
  FILE *ofile = fopen(path.c_str(), "w");
  if (ofile == nullptr) {
    fprintf(stderr, "open file %s failed.\n", path.c_str());
    if (exit_on_failure) exit(EXIT_FAILURE);
  }
  return ofile;
}

FILE *read_file(const std::string &path, bool exit_on_failure = true) {
  FILE *ifile = fopen(path.c_str(), "r");
  if (ifile == nullptr) {
    fprintf(stderr, "open file %s failed.\n", path.c_str());
    if (exit_on_failure) exit(EXIT_FAILURE);
  }
  return ifile;
}

//===============================for POD Types==================================================
template<typename T,
         typename std::enable_if<std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value,
                                 int>::type = 0>
void write(FILE *ofile, const T &v) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  fwrite(&v, sizeof(T), 1, ofile);
}

template<typename T,
         typename std::enable_if<std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value,
                                 int>::type = 0>
void read(FILE *ifile, T &v) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  fread(&v, sizeof(T), 1, ifile);
}

//==============================for pair<A,B> ==========================================================
template<typename A, typename B>
void write(FILE *ofile, const std::pair<A, B> &v) {
  write(ofile, v.first);
  write(ofile, v.second);
}

template<typename A, typename B>
void read(FILE *ifile, std::pair<A, B> &v) {
  read(ifile, v.first);
  read(ifile, v.second);
}

//==============================for Vector<POD> Types (for efficiency)==========================================
template<typename T,
         typename std::enable_if<std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value,
                                 int>::type = 0>
void write(FILE *ofile, const std::vector<T> &arr) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  size_t size = arr.size();
  write(ofile, size);
  fwrite(arr.data(), sizeof(T), size, ofile);
}

template<typename T,
         typename std::enable_if<std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value,
                                 int>::type = 0>
void read(FILE *ifile, std::vector<T> &arr) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  size_t size;
  read(ifile, size);
  arr.resize(size);
  fread(arr.data(), sizeof(T), size, ifile);
}

//==============================for Vector<Non-POD> Types==========================================
template<typename T,
         typename std::enable_if_t<
             !(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value), bool> = true>
void write(FILE *ofile, const std::vector<T> &arr) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  size_t size = arr.size();//size should be unsigned long
  write(ofile, size);
  for (int i = 0; i < size; ++i) { write(ofile, arr[i]); }
}

template<typename T,
         typename std::enable_if_t<
             !(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value), bool> = true>
void read(FILE *ifile, std::vector<T> &arr) {
  size_t size;//size should be unsigned long
  read(ifile, size);
  arr.resize(size);
  for (int i = 0; i < size; ++i) { read(ifile, arr[i]); }
}

//====================================for dequeue========================================================
template<typename T>
void write(FILE *ofile, const std::deque<T> &q) {
  //  static_assert(std::is_trivially_copyable<T>::value || std::is_trivially_copy_constructible<T>::value);
  size_t size = q.size();//size should be unsigned long
  write(ofile, size);
  for (int i = 0; i < size; ++i) { write(ofile, q[i]); }
}

template<typename T>
void read(FILE *ifile, std::deque<T> &q) {
  size_t size;//size should be unsigned long
  read(ifile, size);
  q.resize(size);
  for (int i = 0; i < size; ++i) { read(ifile, q[i]); }
}

//==================================for Map==============================================================
template<typename KEY, typename VALUE, template<typename...> typename MAP>
auto write(FILE *ofile, const MAP<KEY, VALUE> &mp) -> decltype(MAP<KEY, VALUE>()[KEY()], void()) {
  size_t size = mp.size();//size should be unsigned long
  write(ofile, size);
  for (const auto &e : mp) { write(ofile, e); }
}

template<typename KEY, typename VALUE, template<typename...> typename MAP>
auto read(FILE *ifile, MAP<KEY, VALUE> &mp) -> decltype(MAP<KEY, VALUE>()[KEY()], void()) {
  size_t size;//size should be unsigned long
  read(ifile, size);
  std::pair<KEY, VALUE> p;
  for (int i = 0; i < size; ++i) {
    read(ifile, p);
    mp[p.first] = std::move(p.second);
  }
}

void finalize_reading(FILE *fin) {
  if (feof(fin)) {
    mlog("read exceed the file size");
  } else if (fgetc(fin) != EOF) {
    mlog("file is not fully read");
  } else {
    fclose(fin);
    return;
  }
  fclose(fin);
  exit(-1);
}

#define check_eof(fin) finalize_reading(fin)

size_t get_filesize(const std::string &path) {
  std::filesystem::path p(path);
  return std::filesystem::file_size(p);
}

#endif//EXP_CODE_LIBS_FILE_IO_H_
