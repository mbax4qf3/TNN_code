#! /bin/bash -e
echo "Compiling.."
g++ -std=c++17 -O2 -w indexing.cpp -o indexing
g++ -std=c++17 -O2 -w query.cpp -o query

echo "Indexing"
./indexing -p datasets/example -k 3 -d 005 -c N -o N

echo "Querying"
./query -p datasets/example -k 3 -d 005 -c N -o N